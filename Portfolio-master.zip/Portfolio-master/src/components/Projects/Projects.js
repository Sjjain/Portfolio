import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import ProjectCard from "./ProjectCards";
import Particle from "../Particle";
import pro from "../../Assets/Projects/pro.png";
import newproj from "../../Assets/Projects/newproj.png";

function Projects() {
  return (
    <Container fluid className="project-section">
      <Particle />
      <Container>
        <h1 className="project-heading">
          My Recent <strong className="purple">Works </strong>
        </h1>
        <p style={{ color: "white" }}>
          Here are a few projects I've worked on recently.
        </p>
        <Row style={{ justifyContent: "center", paddingBottom: "10px" }}>
          <Col md={4} className="project-card">
            <ProjectCard
              imgPath={pro}
              isBlog={false}
              title="Online Entertainment"
              description="."
              ghLink="https://sjjain.github.io/FrontEnd-Website/"
              
            />
          </Col>
        </Row>
        <Row style={{ justifyContent: "center", paddingBottom: "10px" }}>
          <Col md={4} className="project-card">
            <ProjectCard
              imgPath={newproj}
              isBlog={false}
              title="Fashion Website"
              description="."
              ghLink="https://github.com/Sjjain/fashion-website---Frontend" 
            />
          </Col>
        </Row>
      </Container>
    </Container>
  );
}

export default Projects;
